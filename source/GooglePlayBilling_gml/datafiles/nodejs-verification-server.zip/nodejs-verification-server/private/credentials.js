
export default {
    // To create this account and get the required information please
    // follow the instructions on the site: https://developers.google.com/android-publisher/getting_started
    private_key: "YOUR PRIVATE KEY GOES HERE",
    client_email: "YOUR CLIENT EMAIL GOES HERE"
}